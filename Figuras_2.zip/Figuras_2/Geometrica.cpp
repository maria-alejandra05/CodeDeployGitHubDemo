#include "Geometrica.h"
#include <iostream>

using namespace std;

float Geometrica::area() {return 0.0;}
float Geometrica::perimetro() {return 0.0;}

Geometrica::Geometrica() {}

Geometrica::~Geometrica() {cout << "Llamando destructor de Geometrica" << endl;}
