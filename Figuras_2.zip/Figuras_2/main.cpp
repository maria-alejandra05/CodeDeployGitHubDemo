#include <iostream>
#include "Circulo.h"
#include "Cuadrado.h"
#include "Triangulo.h"
#include "Pentagono.h"

#include "stdio.h"

#include <fstream>

#include <vector>

#include <string.h>

using namespace std;

int main(int argc, char** argv){

    if(argc != 3)
    {
        cout <<"Por favor inserte archivo de lectura y archivo a crear, asi: "<<endl;
        cout <<" ./Ejecutable <Ruta>/<Nombre_archivo_lectura> <Ruta>/<Nombre_archivo_crear>"<<endl;
        return 1;
    }

    vector<Geometrica*> vFig;
    int tipo = 0;

    float radio;
    float lado;
    float altura;
    float base;

    Geometrica* pG;

    std::string My_help;
    My_help=argv[1];
    std::ifstream Archive;
    Archive.open(My_help);

    cout << "se a abierto " << My_help << endl;

    size_t indice_0;
    size_t indice_1;

    enum figura {circulo = 1, cuadrado, triangulo, pentagono};

    int i=0;

    while (Archive.is_open() && !Archive.eof()) {
        i++;
        getline(Archive, My_help);
        indice_0 = My_help.find(" ");
        tipo = atoi(My_help.substr(0,indice_0).c_str());
        switch (tipo) {

        case circulo:

            indice_1 = My_help.find(" ",indice_0+1);
            radio = atof(My_help.substr(indice_0+1,indice_1).c_str());
            pG = new Circulo( radio );
            break;

        case cuadrado:

            indice_1 = My_help.find(" ",indice_0+1);
            lado = atof(My_help.substr(indice_0+1,indice_1).c_str());
            pG = new Cuadrado( lado );
            break;

        case triangulo:

            indice_1 = My_help.find(" ",indice_0+1);
            base = atof(My_help.substr(indice_0+1,indice_1).c_str());

            indice_0=indice_1;
            indice_1 = My_help.find(" ",indice_1+1);
            altura = atof(My_help.substr(indice_0+1,indice_1).c_str());

            pG = new Triangulo( base, altura );
            break;
        case pentagono:

            indice_1 = My_help.find(" ",indice_0+1);
            lado = atof(My_help.substr(indice_0+1,indice_1).c_str());
            pG = new Pentagono( lado );
            break;
        default:
            cout << "Figura no encontrada: Revise la linea " << i << endl;
            continue;
            break;
        }

        indice_0=indice_1;
        indice_1 = My_help.find(" ",indice_1+1);
        pG->setX(atof(My_help.substr(indice_0+1,indice_1).c_str()));

        indice_0=indice_1;
        indice_1 = My_help.find(" ",indice_1+1);
        pG->setY(atof(My_help.substr(indice_0+1,indice_1).c_str()));

        pG->setAngulo(atof(My_help.substr(indice_1+1).c_str()));

        vFig.push_back( pG );
     }

    Archive.close();



    std::ofstream Archive_saquese;
    Archive_saquese.open(argv[2], std::ofstream::out | std::ofstream::app);

    while(Archive_saquese.is_open()){
        for (int i=0; i < vFig.size(); i++){
            Archive_saquese << "Figura: " << vFig.at(i)->nameClass()<<endl
                 << "X: " << vFig.at(i)->getX() << " Y: " << vFig.at(i)->getY() << " Angulo: " << vFig.at(i)->getAngulo() << endl
                 << "Perímetro: " << vFig.at(i)->perimetro() << " y área: " << vFig.at(i)->area() << endl;
        }
        Archive_saquese << std::endl;
        break;
    }
Archive_saquese.close();


    for (int i = 0; i < vFig.size(); i++){
        delete vFig.at(i);
    }


    return 0;
}
